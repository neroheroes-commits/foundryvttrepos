export const ROGUETRADER = {};

/**
 * Add any settings here.
 * @type {Object}
 */
ROGUETRADER.settings = {}
