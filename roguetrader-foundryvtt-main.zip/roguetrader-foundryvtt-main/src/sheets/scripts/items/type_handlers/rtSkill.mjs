
/**
 * This method is the starting point for handling all ItemSheet getData changes.
 * @param {*} context 
 * @param {*} sheet 
 */
export function handler(context, sheet)
{
    // Nothing for now.
}