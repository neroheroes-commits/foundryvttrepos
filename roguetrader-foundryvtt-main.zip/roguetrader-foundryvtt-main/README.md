# RogueTrader-FoundryVTT

A simple Rogue Trader game system for Foundry VTT.

SVG Images taken from [Game-icons.net](https://game-icons.net/) under the [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/) license. No files were edited after download.