#### Talent: Warp Conduit (RTCR p. 108)
The description says to "subtract -10", but that's technically adding 10, which would be bad. I assume it's supposed to be "subtract 10", which is equivalent to the -10 originally stated. I've made that change in the Trait item.

