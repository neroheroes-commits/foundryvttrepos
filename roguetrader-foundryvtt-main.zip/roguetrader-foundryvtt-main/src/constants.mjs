
/******************************************
 *	 MODIFY THESE CONSTANTS TO SUIT YOUR
 *   TEST ENVIRONMENT. MAKE SURE YOUR GIT
 *   IGNORE FILE IS UP TO DATE!
 ******************************************/
export var systemFolder = "roguetraderdev";